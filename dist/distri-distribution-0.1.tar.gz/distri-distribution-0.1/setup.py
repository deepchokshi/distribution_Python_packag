from setuptools import setup

setup(name='distri-distribution',
      version='0.1',
      description='Gaussian distributions',
      packages=['distri-distribution'],
      author = 'Deep Chokshi',
      author_email = 'deep.chokshi@outlook.com',
      zip_safe=False)
